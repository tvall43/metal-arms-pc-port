;Per-pixel point light attenuation.


;Need to pass in the following:
; Point Light Color*MaterialColor	[22]
;			  Ambient				[CV_LIGHT1_AMBIENT]
;			  Position (xyz)		[14]
;			  Attenuation (a0,a1,a2)[37]
; Directional Light Clr*Material	[23]
;			  Direction				[15]

vs.1.0




; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform position to eye space
dp4 r1.x, v0, c[6]
dp4 r1.y, v0, c[7]
dp4 r1.z, v0, c[8]
dp4 r1.w, v0, c[9]

; Transform normal to eye space
dp3 r0.x, v1, c[6]
dp3 r0.y, v1, c[7]
dp3 r0.z, v1, c[8]

; Normalize transformed normal
dp3 r0.w, r0, r0
rsq r0.w, r0.w	
mul r0, r0, r0.w

; ************** Per-Pixel Point 1 ***************
mad oT0.xy, c[37].ww, r1.xz, c[37].xz
mad oT1.x, c[37].w, r1.y, c[37].y
mov oT1.y, c[73]

mov oD0, c[33]

; ************* BumpMap Code *********************
; Calculate the vector to the light from the world vertex
add r3, -r1, c[31]

;*****TEMP CODE HERE**********
;mov v4.yzw, c[0]
;mov v4.x, c[1]
;mov v5.xzw, c[0]
;mov v5.y, c[1]
;*****************************

; Transform basis vectors to world space
dp3 r6.x, v4, c[6]
dp3 r6.y, v4, c[7]
dp3 r6.z, v4, c[8]

dp3 r7.x, v5, c[6]
dp3 r7.y, v5, c[7]
dp3 r7.z, v5, c[8]

; transform light by basis vectors to put it
; into texture space
dp3 r8.x, r6.xyz, r3
dp3 r8.y, r7.xyz, r3
dp3 r8.z, r0.xyz, r3

; Normalize the light vector
dp3 r8.w, r8, r8
rsq r8.w, r8.w
mul r8, r8, r8.w

; Scale to 0-1
add r8, r8, c[1]
mul oT3, r8, c[73]
mov oT3.w, c[1]

; output tex coords
mul oT2.xy, v3, c[30]
