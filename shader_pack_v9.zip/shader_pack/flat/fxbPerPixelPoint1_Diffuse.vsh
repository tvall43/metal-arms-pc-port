;Per-pixel point light attenuation.


;Need to pass in the following:
; Point Light Color*MaterialColor	[22]
;			  Ambient				[CV_LIGHT1_AMBIENT]
;			  Position (xyz)		[14]
;			  Attenuation (a0,a1,a2)[37]
; Directional Light Clr*Material	[23]
;			  Direction				[15]

vs.1.0



; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform position to eye space
dp4 r7.x, v0, c[6]
dp4 r7.y, v0, c[7]
dp4 r7.z, v0, c[8]
dp4 r7.w, v0, c[9]

; Transform normal to eye space
dp3 r6.x, v1, c[6]
dp3 r6.y, v1, c[7]
dp3 r6.z, v1, c[8]

; Normalize transformed normal
dp3 r6.w, r6, r6
rsq r6.w, r6.w	
mul r6, r6, r6.w

; ************** Per-Pixel Point 1 ***************
mad oT0.xy, c[37].ww, r7.xz, c[37].xz
mad oT1.x, c[37].w, r7.y, c[37].y
mov oT1.y, c[73]

sub r0, c[31], r7
dp3 r1.w, r0, r0
rsq r0.w, r1.w
;r0 is Vtx -> Light normalized vector.
mul r0, r0, r0.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r1, r6, r0
sge r1, r1, c[93].x

mul oD0, r1, c[33]
;mov oD0, c[33]
