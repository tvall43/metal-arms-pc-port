;Per-pixel spot light mask


;Need to pass in the following:
; Point Light Color*MaterialColor	[22]
;			  Ambient				[CV_LIGHT1_AMBIENT]
;			  Position (xyz)		[14]
;			  Attenuation (a0,a1,a2)[37]
; Directional Light Clr*Material	[23]
;			  Direction				[15]

vs.1.0




; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform position to world space
dp4 r0.x, v0, c[6]
dp4 r0.y, v0, c[7]
dp4 r0.z, v0, c[8]
dp4 r0.w, v0, c[9]

; Transform normal to world space
dp3 r1.x, v1, c[6]
dp3 r1.y, v1, c[7]
dp3 r1.z, v1, c[8]

; Normalize transformed normal
dp3 r1.w, r1, r1
rsq r1.w, r1.w	
mul r1, r1, r1.w

;*****TEMP CODE HERE**********
;mov v4.yzw, c[0]
;mov v4.x, c[1]
;mov v5.xzw, c[0]
;mov v5.y, c[1]
;*****************************

; Transform basis vectors to world space
dp3 r3.x, v4, c[6]
dp3 r3.y, v4, c[7]
dp3 r3.z, v4, c[8]

dp3 r4.x, v5, c[6]
dp3 r4.y, v5, c[7]
dp3 r4.z, v5, c[8]

/////////////////////////////////////
// Calculate half angle vector

// transform vertex position to world space
//  to calculate V, vector to viewer in world
//  space.

; Half angle vector is  (L+V)/||L+V||  or Normalize( L+V )
;  ||a|| is magnitude of a
;  L = vec to light from vertex point
;  V = vec to viewer from vertex point

// vertex position - eye position
// eye position - vertex position
add r5,  c[ 0 ], -r0.xyz

; Normalize eye vec
dp3 r5.w, r5, r5
rsq r5.w, r5.w
mul r5,   r5, r5.w

// Add them to average & create half angle vector
add r9,  c[88], r5

;  Normalize it
dp3 r9.w, r9, r9
rsq r9.w, r9.w
mul r9,   r9, r9.w

/////////////////////////////////////////////////
; Transform half angle vector to local space and
;  output to tex coord set 3 for specular calc

dp3 oT1.x, r9, r3
dp3 oT1.y, r9, r4
dp3 oT1.z, r9, r1
mov oT1.w, c[ 1 ]

mov oT2, c[0]

mov oT0, v3

mov oD0, c[90]
