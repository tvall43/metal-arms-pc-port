;Basic Passthru: vertex color & texture coord.


vs.1.0



; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

;dp4 r8.z, v0, c[8]
;dp4 R_WORLD_VERTEX.y, v0, c[83]

mov oD0.xyz, c[68]
mov oD0.w, v2.w

mov r0.xy, v3
mov r0.z, c[1]

dp3 r1.x, r0, c[74]
dp3 r1.y, r0, c[75]
mov r1.zw, c[0]

mov r0.xy, v4

dp3 r2.x, r0, c[76]
dp3 r2.y, r0, c[77]

mov oT0.xy, r1
mov oT1.xy, r2

mul oT3.xy, r1, c[35]

;*******************do reflection vector here
dp4 r8.x, v0, c[6]
dp4 r8.y, v0, c[7]
dp4 r8.z, v0, c[8]
dp4 r8.w, v0, c[9]

; Create r9, the normalized vector from the eye to the vertex
dp3 r9.w, r8, r8
rsq r9.w, r9.w		
mul r9, r8, r9.w

; Transform normal to eye-space
; We use the inverse transpose of the worldview
; matrix to do this
dp3 r7.x, v1, c[6]
dp3 r7.y, v1, c[7]
dp3 r7.z, v1, c[8]

; Need to re-normalize normal
dp3 r7.w, r7, r7
rsq r7.w, r7.w
mul r7, r7, r7.w

; Calculate E - 2*(E dot N)*N
dp3 r6, r9, r7
add r6, r6, r6
mul r7, r7, r6

;Now (s,t)*0.5f + 0.5f
add r9, r9, -r7
mul r9, r9, c[73]
add oT2, r9, c[73]

mov oT2.w, c[1].x
;****************************
