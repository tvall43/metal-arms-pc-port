;Per-pixel shadow projection.


vs.1.0




; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform position to world space
dp4 r0.x, v0, c[82]
dp4 r0.y, v0, c[83]
dp4 r0.z, v0, c[84]
dp4 r0.w, v0, c[85]

dp3 r1.x, v1, c[82]
dp3 r1.y, v1, c[83]
dp3 r1.z, v1, c[84]

; ************** Per-Pixel Point 1 ***************
dp4 oT0.x, r0, c[74]
dp4 oT0.y, r0, c[75]
dp4 oT0.w, r0, c[76]
dp4 oT0.z, r0, c[77]

add r5, r0, -c[18]
dp3 r9.w, r5, r5
mov r7.w, r9.w
mul r9.w, r9.w, c[18].w

max r9.w, c[0], r9.w
min r9.w, c[1], r9.w

add r9.w, c[1], -r9.w

rsq r7.w, r7.w
mul r5, r5, r7.w
dp3 r8.w, r5, c[14]
mad r8.w, r8.w, c[22].z, c[22].y

max r8.w, c[0], r8.w
min r8.w, c[1], r8.w

dp3 r7.w, r1, c[14]
mul r7.w, r7.w, c[94]

max r7.w, c[0], r7.w
min r7.w, c[1], r7.w

mul r8.w, r8.w, r7.w
mul oD0, r8.w, r9.w

dp3 r0.x, r0, c[69]
add oT1.xyz, r0.x, c[69].w
mov oT1.w, c[1]
