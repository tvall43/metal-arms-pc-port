
vs.1.0




; Transform position
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

dp4 r8.x, v0, c[6]
dp4 r8.y, v0, c[7]
dp4 r8.z, v0, c[8]
dp4 r8.w, v0, c[9]

; Create r3, the normalized vector from the eye to the vertex
dp3 r3.w, r8, r8
rsq r3.w, r3.w		
mul r3, r8, r3.w

; Transform normal to eye-space
; We use the inverse transpose of the worldview
; matrix to do this
dp3 r9.x, v1, c[6]
dp3 r9.y, v1, c[7]
dp3 r9.z, v1, c[8]

; Need to re-normalize normal
dp3 r9.w, r9, r9
rsq r9.w, r9.w
mul r9, r9, r9.w

; Calculate E - 2*(E dot N)*N
dp3 r4, r3, r9
add r4, r4, r4
mul r9, r9, r4

;mov oT0, v3

;Now (s,t)*0.5f + 0.5f
add r3, r3, -r9
mul r3, r3, c[73]
add oT1, r3, c[73]

mov oT1.w, c[1].x

mov r0.xy, v3
mov r0.z, c[1]

dp3 r1.x, r0, c[74]
dp3 r1.y, r0, c[75]

mov oT0.xy, r1
;oT1 = reflection vector.
;mov oT2.xy, r1
;mov oT3.xy, r1

mov oT3.xyz, c[68]

;Lighting
dp4 r6.y, v0, c[83]
mov r6.z, r8.z

mov r5, c[70]
add r5, r5, v2

; *************** Directional Light 1 ************************
dp3 r4, r9, -c[14]
;mov r4, c[1]
max r4, c[0], r4

; add the (diffuse color * diffuse light color * diffuse intensity(r3.x))
mul r2, c[69], r4
mad r5, c[22], r2, r5

min r5, c[1], r5

; *************** Point Light 1 ************************
; Calculate vector from vertex to light in eye space
add r1, c[15],-r8
dp3 r2.w, r1, r1	
rsq r1.w, r2.w

; Get the attenuation
dst r2, r2.wwww, r1.wwww		; (1, d, d*d, 1/d)
dp3 r2.w, r2, c[38]		; (a0 + a1*d + a2*d2)
rcp r8.w, r2.w									; 1 / (a0 + a1*d + a2*d)	

; Normalize the vertex to the light vector
mul r1, r1, r1.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r4, r9, -r1
max r4, c[0], r4

; Scale the factors by the attenuation
mul r4, r4, r8.w

;Spot light attenuation.
dp3 r2, r1, -c[48]
mad r2, r2, c[49].z, c[49].y
min r2, c[1], r2
max r2, c[0], r2
mul r4, r4, r2

; add the (diffuse color * diffuse light color * diffuse intensity(r4.x))
mul r2, c[69], r4
;max r2, c[0], r2

mad r5, c[23], r2, r5

; *************** Point Light 2 ************************
; Calculate vector from vertex to light in eye space
add r1, c[16],-r8
dp3 r2.w, r1, r1	
rsq r1.w, r2.w

; Get the attenuation
dst r2, r2.wwww, r1.wwww		; (1, d, d*d, 1/d)
dp3 r2.w, r2, c[39]		; (a0 + a1*d + a2*d2)
rcp r8.w, r2.w									; 1 / (a0 + a1*d + a2*d)	

; Normalize the vertex to the light vector
mul r1, r1, r1.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r4, r9, -r1
max r4, c[0], r4

; Scale the factors by the attenuation
mul r4, r4, r8.w

; add the (ambient color * ambient light color)
;mov r5, c[CV_LIGHT3_AMBIENT]
;Spot light attenuation.
dp3 r2, r1, -c[50]
mad r2, r2, c[51].z, c[51].y
max r2, c[0], r2
min r2, c[1], r2
mul r4, r4, r2

; add the (diffuse color * diffuse light color * diffuse intensity(r4.x))
mul r2, c[69], r4
;max r2, c[0], r2

mad r5, c[24], r2, r5

; *************** Point Light 3 ************************
; Calculate vector from vertex to light in eye space
add r1, c[17],-r8
dp3 r2.w, r1, r1	
rsq r1.w, r2.w

; Get the attenuation
dst r2, r2.wwww, r1.wwww		; (1, d, d*d, 1/d)
dp3 r2.w, r2, c[40]		; (a0 + a1*d + a2*d2)
rcp r8.w, r2.w									; 1 / (a0 + a1*d + a2*d)	

; Normalize the vertex to the light vector
mul r1, r1, r1.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r4, r9, -r1
max r4, c[0], r4

; Scale the factors by the attenuation
mul r4, r4, r8.w

;Spot light attenuation.
dp3 r2, r1, -c[52]
mad r2, r2, c[53].z, c[53].y
max r2, c[0], r2
min r2, c[1], r2
mul r4, r4, r2

; add the (diffuse color * diffuse light color * diffuse intensity(r4.x))
mul r2, c[69], r4
;max r2, c[0], r2

mad r5, c[25], r2, r5

; *************** Point Light 4 ************************
; Calculate vector from vertex to light in eye space
add r1, c[18],-r8
dp3 r2.w, r1, r1	
rsq r1.w, r2.w

; Get the attenuation
dst r2, r2.wwww, r1.wwww		; (1, d, d*d, 1/d)
dp3 r2.w, r2, c[41]		; (a0 + a1*d + a2*d2)
rcp r8.w, r2.w									; 1 / (a0 + a1*d + a2*d)	

; Normalize the vertex to the light vector
mul r1, r1, r1.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r4, r9, -r1
max r4, c[0], r4

; Scale the factors by the attenuation
mul r4, r4, r8.w

;Spot light attenuation.
dp3 r2, r1, -c[54]
mad r2, r2, c[55].z, c[55].y
max r2, c[0], r2
min r2, c[1], r2
mul r4, r4, r2

; add the (diffuse color * diffuse light color * diffuse intensity(r4.x))
mul r2, c[69], r4
;max r2, c[0], r2

mad r5, c[26], r2, r5

; Clamp it just to be safe.
min r5, c[1], r5
max r5, c[0], r5

mov oD0.xyz, r5
mov oD0.w, v2.w

mov oT2.xyz, c[72]

mad r2.z, r6.z, c[29].x, c[29].y
mad r2.w, r6.y, c[29].z, c[29].w
min r2.zw, r2, c[1]
max r2.zw, r2, c[95]
mad oT2.w, r2.z, r2.w, c[93].w
