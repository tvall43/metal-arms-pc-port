;Basic Vertex Lighting: 1 Directional + 1 Point Light


;Need to pass in the following:
; Point Light Color*MaterialColor	[22]
;			  Ambient				[CV_LIGHT1_AMBIENT]
;			  Position (xyz)		[14]
;			  Attenuation (a0,a1,a2)[37]
; Directional Light Clr*Material	[23]
;			  Direction				[15]

vs.1.0



; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform position to eye space
dp4 r0.x, v0, c[6]
dp4 r0.y, v0, c[7]
dp4 r0.z, v0, c[8]
dp4 r0.w, v0, c[9]

; Transform normal to eye space
dp3 r1.x, v1, c[6]
dp3 r1.y, v1, c[7]
dp3 r1.z, v1, c[8]

; Normalize transformed normal
dp3 r1.w, r1, r1
rsq r1.w, r1.w	
mul r1, r1, r1.w

; *************** Directional Light 1 ************************
; This is the intensity of the specular component
; Calculate half vector (light vector + constant eye vector)
mov r9, c[88]
add r9, r9, c[46]

; normalize half-vector
dp3 r9.w, r9, r9
rsq r9.w, r9.w												
mul r9, r9, r9.w	

; Dot normal with half-vector.  
dp3 r3.x, r1, c[88]
dp3 r3.yz, r1, r9
;mov r3.x, c[1]
mov r3.w, c[45]

;mov r4.x, r3.y
lit r4, r3

; add the (diffuse color * diffuse light color * diffuse intensity(r3.x))
mul r6, c[90], r4.z

; Clamp it just to be safe.
min r6, c[1], r6
max r6, c[0], r6

mov oD0, r6
mov oT0, v3