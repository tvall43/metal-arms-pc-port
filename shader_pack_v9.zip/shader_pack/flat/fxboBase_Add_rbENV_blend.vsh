;Basic Passthru: vertex color & texture coord.


vs.1.0



//Blend my vertex
dp4 r1.x, v0, c[48]
dp4 r1.y, v0, c[49]
dp4 r1.z, v0, c[50]

//second bone results -> r2
dp4 r2.x, v0, c[51]
dp4 r2.y, v0, c[52]
dp4 r2.z, v0, c[53]

//third bone results -> r3
dp4 r3.x, v0, c[54]
dp4 r3.y, v0, c[55]
dp4 r3.z, v0, c[56]

//fourth bone results -> r4
dp4 r4.x, v0, c[57]
dp4 r4.y, v0, c[58]
dp4 r4.z, v0, c[59]

//find fourth bone weight: w4 = 1 - (w1+w2+w3)
add r5.x, v1.x, v1.y
add r5.x, r5.x, v1.z
add r5.x, c[1], -r5.x

//Blend verts by weight: v1*w1 + v2*w2 + v3*w3 + v4*w4 
mul r1.xyz, r1.xyz, v1.x
mad r2, r2.xyz, v1.y, r1.xyz
mad r3, r3.xyz, v1.z, r2.xyz
mad r4, r4.xyz, r5.x, r3.xyz

mov r4.w, c[1].z //set w to one
//r4 now contains final position

; Transform position to clip space and output it
dp4 oPos.x, r4, c[64]
dp4 oPos.y, r4, c[65]
dp4 oPos.z, r4, c[66]
dp4 oPos.w, r4, c[67]

dp4 r8.x, v0, c[6]
dp4 r8.y, v0, c[7]
dp4 r8.z, v0, c[8]
dp4 r8.w, v0, c[9]

; Create r3, the normalized vector from the eye to the vertex
dp3 r3.w, r8, r8
rsq r3.w, r3.w		
mul r3, r8, r3.w

; Transform normal to eye-space
; We use the inverse transpose of the worldview
; matrix to do this
dp3 r9.x, v2, c[6]
dp3 r9.y, v2, c[7]
dp3 r9.z, v2, c[8]

; Need to re-normalize normal
dp3 r9.w, r9, r9
rsq r9.w, r9.w
mul r9, r9, r9.w

; Calculate E - 2*(E dot N)*N
dp3 r4, r3, r9
add r4, r4, r4
mul r9, r9, r4

;mov oT0, v4

;Now (s,t)*0.5f + 0.5f
add r3, r3, -r9
mul r3, r3, c[73]
add oT1, r3, c[73]

mov r0.xy, v4
mov r0.z, c[1]

dp3 oT0.x, r0, c[74]
dp3 oT0.y, r0, c[75]

mov oD0, c[68]
mov oD1, c[68]
