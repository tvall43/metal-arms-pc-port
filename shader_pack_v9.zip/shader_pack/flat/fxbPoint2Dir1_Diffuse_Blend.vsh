;Basic Vertex Lighting: 1 Directional + 1 Point Light


;Need to pass in the following:
; Point Light Color*MaterialColor	[22]
;			  Ambient				[CV_LIGHT1_AMBIENT]
;			  Position (xyz)		[14]
;			  Attenuation (a0,a1,a2)[37]
; Directional Light Clr*Material	[23]
;			  Direction				[15]

vs.1.0



//Blend my vertex ;
dp4 r1.x, v0, c[48]
dp4 r1.y, v0, c[49]
dp4 r1.z, v0, c[50]

//second bone results -> r2
dp4 r2.x, v0, c[51]
dp4 r2.y, v0, c[52]
dp4 r2.z, v0, c[53]

//third bone results -> r3
dp4 r3.x, v0, c[54]
dp4 r3.y, v0, c[55]
dp4 r3.z, v0, c[56]

//fourth bone results -> r4
dp4 r4.x, v0, c[57]
dp4 r4.y, v0, c[58]
dp4 r4.z, v0, c[59]

//find fourth bone weight: w4 = 1 - (w1+w2+w3)
add r5.x, v1.x, v1.y
add r5.x, r5.x, v1.z
add r5.x, c[1], -r5.x

//Blend verts by weight: v1*w1 + v2*w2 + v3*w3 + v4*w4 
mul r1.xyz, r1.xyz, v1.x
mad r2, r2.xyz, v1.y, r1.xyz
mad r3, r3.xyz, v1.z, r2.xyz
mad r4, r4.xyz, r5.x, r3.xyz

mov r4.w, c[1].z //set w to one
//r4 now contains final position

; Transform position to clip space and output it
dp4 oPos.x, r4, c[64]
dp4 oPos.y, r4, c[65]
dp4 oPos.z, r4, c[66]
dp4 oPos.w, r4, c[67]

; Transform position to eye space
dp4 r0.x, r4, c[10]
dp4 r0.y, r4, c[11]
dp4 r0.z, r4, c[12]
dp4 r0.w, r4, c[13]

//Blend my normal
dp3 r1.x, v2, c[48]
dp3 r1.y, v2, c[49]
dp3 r1.z, v2, c[50]

//second bone results -> r2
dp3 r2.x, v2, c[51]
dp3 r2.y, v2, c[52]
dp3 r2.z, v2, c[53]

//third bone results -> r3
dp3 r3.x, v2, c[54]
dp3 r3.y, v2, c[55]
dp3 r3.z, v2, c[56]

//fourth bone results -> r4
dp3 r4.x, v2, c[57]
dp3 r4.y, v2, c[58]
dp3 r4.z, v2, c[59]

//find fourth bone weight: w4 = 1 - (w1+w2+w3)
add r5.x, v1.x, v1.y
add r5.x, r5.x, v1.z
add r5.x, c[1], -r5.x

//Blend normals by weight: v1*w1 + v2*w2 + v3*w3 + v4*w4 
mul r1.xyz, r1.xyz, v1.x
mad r2, r2.xyz, v1.y, r1.xyz
mad r3, r3.xyz, v1.z, r2.xyz
mad r4, r4.xyz, r5.x, r3.xyz

; Transform normal to eye space
dp3 r1.x, r4, c[10]
dp3 r1.y, r4, c[11]
dp3 r1.z, r4, c[12]

; Normalize transformed normal
dp3 r1.w, r1, r1
rsq r1.w, r1.w	
mul r1, r1, r1.w

mov r6, c[70]
add r6, r6, v3
;mad r6, v3, c[73], r6

; *************** Directional Light 1 ************************
dp3 r3.x, r1, c[14]
max r3.x, c[0], r3.x

; add the (diffuse color * diffuse light color * diffuse intensity(r3.x))
mul r7, c[69], r3.xxxx
mad r6, c[22], r7, r6

; *************** Point Light 1 ************************
; Calculate vector from vertex to light in eye space
add r9, c[15],-r0
dp3 r7.w, r9, r9	
rsq r9.w, r7.w

; Get the attenuation
dst r7, r7.wwww, r9.wwww		; (1, d, d*d, 1/d)
dp3 r7.w, r7, c[38]		; (a0 + a1*d + a2*d2)
rcp r8.w, r7.w									; 1 / (a0 + a1*d + a2*d)	

; Normalize the vertex to the light vector
mul r9, r9, r9.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r4.x, r1, r9
max r4.x, c[0], r4.x

; Scale the factors by the attenuation
mul r4.x, r4.x, r8.w

; add the (ambient color * ambient light color)
;mov r6, c[CV_LIGHT2_AMBIENT]

; add the (diffuse color * diffuse light color * diffuse intensity(r4.x))
mul r7, c[69], r4.xxxx
mad r6, c[23], r7, r6

max r6, c[0], r6

; *************** Point Light 2 ************************
; Calculate vector from vertex to light in eye space
add r9, c[16],-r0
dp3 r7.w, r9, r9	
rsq r9.w, r7.w

; Get the attenuation
dst r7, r7.wwww, r9.wwww		; (1, d, d*d, 1/d)
dp3 r7.w, r7, c[39]		; (a0 + a1*d + a2*d2)
rcp r8.w, r7.w									; 1 / (a0 + a1*d + a2*d)	

; Normalize the vertex to the light vector
mul r9, r9, r9.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r4.x, r1, r9
max r4.x, c[0], r4.x

; Scale the factors by the attenuation
mul r4.x, r4.x, r8.w

; add the (ambient color * ambient light color)
;mov r6, c[CV_LIGHT3_AMBIENT]

; add the (diffuse color * diffuse light color * diffuse intensity(r4.x))
mul r7, c[69], r4.xxxx
mad r6, c[24], r7, r6

; Clamp it just to be safe.
min r6, c[1], r6
max r6, c[0], r6

mov oD0, r6
mov oT0, v4
mov oT1, v4
mov oT2, c[72]