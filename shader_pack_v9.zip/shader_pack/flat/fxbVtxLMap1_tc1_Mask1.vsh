;LightMap Passthru


vs.1.0

;Base UV
;LMap UVs


; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

dp4 r8.z, v0, c[8]
dp4 r9.y, v0, c[83]

mov oT0, v3
mov oT1, v4

add oD0, c[72], v2

mad r2.z, r8.z, c[29].x, c[29].y
mad r2.w, r9.y, c[29].z, c[29].w
min r2.zw, r2, c[1]
max r2.zw, r2, c[95]
mov oT2.xyz, c[0]
mad oT2.w, r2.z, r2.w, c[93].w
