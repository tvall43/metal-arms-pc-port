;Basic Passthru: vertex color & texture coord.


vs.1.0



; Transform position
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

dp4 r8.x, v0, c[6]
dp4 r8.y, v0, c[7]
dp4 r8.z, v0, c[8]
dp4 r8.w, v0, c[9]

; Create r3, the normalized vector from the eye to the vertex
dp3 r3.w, r8, r8
rsq r3.w, r3.w		
mul r3, r8, r3.w

; Transform normal to eye-space
; We use the inverse transpose of the worldview
; matrix to do this
dp3 r9.x, v1, c[6]
dp3 r9.y, v1, c[7]
dp3 r9.z, v1, c[8]

; Need to re-normalize normal
dp3 r9.w, r9, r9
rsq r9.w, r9.w
mul r9, r9, r9.w

; Calculate E - 2*(E dot N)*N
dp3 r4, r3, r9
add r4, r4, r4
mul r9, r9, r4

;mov oT0, v3

;Now (s,t)*0.5f + 0.5f
add r3, r3, -r9
mul r3, r3, c[73]
add oT1, r3, c[73]

mov r0.xy, v3
mov r0.z, c[1]

dp3 r1.x, r0, c[74]
dp3 r1.y, r0, c[75]

mov oT0.xy, r1
;oT1 = reflection vector.
mov oT2.xy, r1
mov oT3.xy, r1

mov oD0, c[68]
mov oD1, c[68]
