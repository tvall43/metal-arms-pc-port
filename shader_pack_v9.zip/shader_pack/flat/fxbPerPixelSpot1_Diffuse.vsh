;Per-pixel spot light mask


;Need to pass in the following:
; Point Light Color*MaterialColor	[22]
;			  Ambient				[CV_LIGHT1_AMBIENT]
;			  Position (xyz)		[14]
;			  Attenuation (a0,a1,a2)[37]
; Directional Light Clr*Material	[23]
;			  Direction				[15]

vs.1.0




; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform position to world space
dp4 r0.x, v0, c[82]
dp4 r0.y, v0, c[83]
dp4 r0.z, v0, c[84]
dp4 r0.w, v0, c[85]

; Transform normal to world space
dp3 r1.x, v1, c[82]
dp3 r1.y, v1, c[83]
dp3 r1.z, v1, c[84]

; Normalize transformed normal
dp3 r1.w, r1, r1
rsq r1.w, r1.w	
mul r1, r1, r1.w

; ************** Per-Pixel Point 1 ***************
dp4 oT0.x, r0, c[74]
dp4 oT0.y, r0, c[75]
dp4 oT0.w, r0, c[76]
dp4 oT0.z, r0, c[77]

dp3 r8.x, r0, -c[86]
add oT1.x, r8.x, -c[86].w
mov oT1.y, c[0]

dp3 r6.x, c[88], r1
max r6.x, c[0].x, r6.x
min r6.x, c[1].x, r6.x

add r9.xyz, r0, -c[31]
dp3 r9.w, r9, r9
mul r9.w, r9.w, c[31].w

min r9.w, c[1], r9.w
max r9.w, c[0], r9.w

add r9.w, c[1], -r9.w

mul r9.w, r9.w, r6.xxxx
mul oD0, c[90], r9.w;r6.xxxx
;mov oD0, c[90]
