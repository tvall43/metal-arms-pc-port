;Basic Vertex Lighting: 1 Directional + 1 Point Light


;Need to pass in the following:
; Point Light Color*MaterialColor	[22]
;			  Ambient				[CV_LIGHT1_AMBIENT]
;			  Position (xyz)		[14]
;			  Attenuation (a0,a1,a2)[37]
; Directional Light Clr*Material	[23]
;			  Direction				[15]

vs.1.0



; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform position to eye space
dp4 r0.x, v0, c[6]
dp4 r0.y, v0, c[7]
dp4 r0.z, v0, c[8]
dp4 r0.w, v0, c[9]

dp4 r5.y, v0, c[83]
mov r5.z, r0.z

; Transform normal to eye space
dp3 r1.x, v1, c[6]
dp3 r1.y, v1, c[7]
dp3 r1.z, v1, c[8]

; Normalize transformed normal
dp3 r1.w, r1, r1
rsq r1.w, r1.w	
mul r1, r1, r1.w

mov r6, c[70]
add r6, r6, v2
;mad r6, v2, c[73], r6

; *************** Directional Light 1 ************************
dp3 r3, r1, c[14]
max r3, c[0], r3

; add the (diffuse color * diffuse light color * diffuse intensity(r3.x))
mul r7, c[69], r3
mad r6, c[22], r7, r6

; *************** Point Light 1 ************************
; Calculate vector from vertex to light in eye space
add r9, c[15],-r0
dp3 r7.w, r9, r9	
rsq r9.w, r7.w

; Get the attenuation
dst r7, r7.wwww, r9.wwww		; (1, d, d*d, 1/d)
dp3 r7.w, r7, c[38]		; (a0 + a1*d + a2*d2)
rcp r8.w, r7.w									; 1 / (a0 + a1*d + a2*d)	

; Normalize the vertex to the light vector
mul r9, r9, r9.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r4, r1, r9
max r4, c[0], r4

; Scale the factors by the attenuation
mul r4, r4, r8.w

;Spot light attenuation.
dp3 r7, r9, -c[48]
mad r7, r7, c[49].z, c[49].y
max r7, c[0], r7
min r7, c[1], r7
mul r4, r4, r7

; add the (diffuse color * diffuse light color * diffuse intensity(r4.x))
mul r7, c[69], r4
;max r7, c[0], r7

mad r6, c[23], r7, r6

max r6, c[0], r6

; *************** Point Light 2 ************************
; Calculate vector from vertex to light in eye space
add r9, c[16],-r0
dp3 r7.w, r9, r9	
rsq r9.w, r7.w

; Get the attenuation
dst r7, r7.wwww, r9.wwww		; (1, d, d*d, 1/d)
dp3 r7.w, r7, c[39]		; (a0 + a1*d + a2*d2)
rcp r8.w, r7.w									; 1 / (a0 + a1*d + a2*d)	

; Normalize the vertex to the light vector
mul r9, r9, r9.w

; Dot normal with light vector (from vertex to light)
; This is the intensity of the diffuse component
dp3 r4, r1, r9
max r4, c[0], r4

; Scale the factors by the attenuation
mul r4, r4, r8.w

;Spot light attenuation.
dp3 r7, r9, -c[50]
mad r7, r7, c[51].z, c[51].y
max r7, c[0], r7
min r7, c[1], r7
mul r4, r4, r7

; add the (diffuse color * diffuse light color * diffuse intensity(r4))
mul r7, c[69], r4
;max r7, c[0], r7

mad r6, c[24], r7, r6

; Clamp it just to be safe.
min r6, c[1], r6
max r6, c[0], r6

mov oD0.xyz, r6
mov oD0.w, v2.w

mov r0.xy, v3
mov r0.z, c[1]

dp3 r1.x, r0, c[74]
dp3 r1.y, r0, c[75]

mov oT0.xy, r1
mov oT1.xy, r1
mov oT2.xyz, c[72]

mad r2.z, r5.z, c[29].x, c[29].y
mad r2.w, r5.y, c[29].z, c[29].w
min r2.zw, r2, c[1]
max r2.zw, r2, c[95]
mad oT2.w, r2.z, r2.w, c[93].w
