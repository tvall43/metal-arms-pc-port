;Basic Vertex Color Passthru: Used for static vertex lighting (ie WorldGeometry with no dynamic lighting).


vs.1.1




; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

dp4 r5.x, v0, c[82]
dp4 r5.y, v0, c[83]
dp4 r5.z, v0, c[84]
mov r5.w, c[1]

add r3, c[92], -r5
;test;
add r9, c[47], -r5
mad r3, r9, c[47].w, r3

; Normalize final Eye vector
dp3 r3.w, r3, r3
rsq r3.w, r3.w	
mul r3, r3, r3.w

;;
;mov r3, c[92]
mov r0, c[0]
mov r0.x, c[1]

mov r1, c[0]
mov r1.z, c[1]

mov r2, c[0]
mov r2.y, c[1]

;dp3 oT1.x, r0, c[82];
;dp3 oT1.y, r1, c[82];
;dp3 oT1.z, r2, c[82];
mov oT1.xyz, r0
mov oT1.w, r3.x

;dp3 oT2.x, r0, c[83];
;dp3 oT2.y, r1, c[83];
;dp3 oT2.z, r2, c[83];
mov oT2.xyz, r1
mov oT2.w, r3.y

;dp3 oT3.x, r0, c[84];
;dp3 oT3.y, r1, c[84];
;dp3 oT3.z, r2, c[84];
mov oT3.xyz, r2
mov oT3.w, r3.z

mov oT0.xy, v1

mov oD0, c[1]
