;Basic Vertex Color Passthru: Used for static vertex lighting (ie WorldGeometry with no dynamic lighting).


vs.1.0


//Blend my vertex;
dp4 r1.x, v0, c[48]
dp4 r1.y, v0, c[49]
dp4 r1.z, v0, c[50]

//second bone results -> r2
dp4 r2.x, v0, c[51]
dp4 r2.y, v0, c[52]
dp4 r2.z, v0, c[53]

//third bone results -> r3
dp4 r3.x, v0, c[54]
dp4 r3.y, v0, c[55]
dp4 r3.z, v0, c[56]

//fourth bone results -> r4
dp4 r4.x, v0, c[57]
dp4 r4.y, v0, c[58]
dp4 r4.z, v0, c[59]

//find fourth bone weight: w4 = 1 - (w1+w2+w3)
add r5.x, v1.x, v1.y
add r5.x, r5.x, v1.z
add r5.x, c[1], -r5.x

//Blend verts by weight: v1*w1 + v2*w2 + v3*w3 + v4*w4 
mul r1.xyz, r1.xyz, v1.x
mad r2, r2.xyz, v1.y, r1.xyz
mad r3, r3.xyz, v1.z, r2.xyz
mad r4, r4.xyz, r5.x, r3.xyz

mov r4.w, c[1].z //set w to one
//r4 now contains final position

; Transform position to clip space and output it
dp4 oPos.x, r4, c[64]
dp4 oPos.y, r4, c[65]
dp4 oPos.z, r4, c[66]
dp4 oPos.w, r4, c[67]

add oD0, v3, c[70]
;mov oT0, v4

mov r0.xy, v4
mov r0.z, c[1]

dp3 r1.x, r0, c[74]
dp3 r1.y, r0, c[75]

;for testing specular
;mov oD0, c[0]
mov oT0.xy, r1
mov oT1.xy, r1
mov oT2, c[72]
