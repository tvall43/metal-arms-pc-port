;Basic Passthru: vertex color & texture coord.


vs.1.0



; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

;dp4 r8.z, v0, c[8]
;dp4 r9.y, v0, c[83]

mov oD0.xyz, c[68]
mov oD0.w, v2.w

mov r0.xy, v3
mov r0.z, c[1]

dp3 r1.x, r0, c[74]
dp3 r1.y, r0, c[75]

mov oT0.xy, r1
mov oT1.xy, r1
mov oT2.xy, r1

;mad r2.z, r8.z, c[29].x, c[29].y
;mad r2.w, r9.y, c[29].z, c[29].w
;max r2.zw, r2, c[0]
;mov oT2.xyz, c[1]
;mad oT2.w, r2.z, r2.w, c[93].w