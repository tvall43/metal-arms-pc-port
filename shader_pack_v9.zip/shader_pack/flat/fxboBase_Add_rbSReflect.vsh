
vs.1.0



; Transform position
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform normal to eye-space
; We use the inverse transpose of the worldview
; matrix to do this
dp3 r9.x, v1, c[6]
dp3 r9.y, v1, c[7]
dp3 r9.z, v1, c[8]

; Need to re-normalize normal
dp3 r9.w, r9, r9
rsq r9.w, r9.w
mul r9, r9, r9.w

;Now (s,t)*0.5f + 0.5f
mul r3, r9, -c[73]
add oT1, r3, c[73]

mov oT1.w, c[1].x

mov r0.xy, v3
mov r0.z, c[1]

dp3 oT0.x, r0, c[74]
dp3 oT0.y, r0, c[75]

mov oD0, c[68]
mov oD1, c[68]
