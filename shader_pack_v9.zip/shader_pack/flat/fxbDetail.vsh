;Basic Passthru: vertex color & texture coord.


vs.1.0


; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

mov oD0, c[68]
mov oD0.w, v2.w

mov r0.xy, v3
mov r0.z, c[1]

dp3 r1.x, r0, c[74]
dp3 r1.y, r0, c[75]

mov oT0.xy, r1.xy

mul oT1.xy, r1.xy, c[35]
