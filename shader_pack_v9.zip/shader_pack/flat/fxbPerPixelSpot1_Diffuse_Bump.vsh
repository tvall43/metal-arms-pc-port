;Per-pixel spot light mask


;Need to pass in the following:
; Point Light Color*MaterialColor	[22]
;			  Ambient				[CV_LIGHT1_AMBIENT]
;			  Position (xyz)		[14]
;			  Attenuation (a0,a1,a2)[37]
; Directional Light Clr*Material	[23]
;			  Direction				[15]

vs.1.0




; Transform position to clip space and output it
dp4 oPos.x, v0, c[2]
dp4 oPos.y, v0, c[3]
dp4 oPos.z, v0, c[4]
dp4 oPos.w, v0, c[5]

; Transform position to world space
dp4 r0.x, v0, c[82]
dp4 r0.y, v0, c[83]
dp4 r0.z, v0, c[84]
dp4 r0.w, v0, c[85]

; Transform normal to world space
dp3 r1.x, v1, c[82]
dp3 r1.y, v1, c[83]
dp3 r1.z, v1, c[84]

; Normalize transformed normal
dp3 r1.w, r1, r1
rsq r1.w, r1.w	
mul r1, r1, r1.w

; ************** Per-Pixel Spot 1 ***************
dp4 oT0.x, r0, c[74]
dp4 oT0.y, r0, c[75]
dp4 oT0.w, r0, c[76]
dp4 oT0.z, r0, c[77]

dp3 r6.x, r0, -c[86]
add oT1.x, r6.x, -c[86].w
mov oT1.y, c[0]

;dp3 r2.x, c[88], r1
;max r2.x, c[0].x, r2.x
;min r2.x, c[1].x, r2.x

; *******************BUMP MAP STUFF HERE********************
; Transform basis vectors to world space
;TEMP CODE HERE
;mov r3.yzw, c[0]
;mov r3.x, c[1]
;mov r4.xzw, c[0]
;mov r4.y, c[1]
;

dp3 r3.x, v4, c[82]
dp3 r3.y, v4, c[83]
dp3 r3.z, v4, c[84]

dp3 r4.x, v5, c[82]
dp3 r4.y, v5, c[83]
dp3 r4.z, v5, c[84]

; transform light by basis vectors to put it
; into texture space
dp3 r5.x, r3.xyz, c[88]
dp3 r5.y, r4.xyz, c[88]
dp3 r5.z, r1.xyz, c[88]

; Normalize the light vector
dp3 r5.w, r5, r5
rsq r5.w, r5.w
mul r5, r5, r5.w

mul oT2.xy, v3, c[30]

; Scale to 0-1
add r5, r5, c[1]
mul oT3, r5, c[73]

add r7.xyz, r0, -c[31]
dp3 r7.w, r7, r7
mul r7.w, r7.w, c[31].w

min r7.w, c[1], r7.w
max r7.w, c[0], r7.w

add r7.w, c[1], -r7.w

mul oD0, c[90], r7.w;

;mov oD0, c[90]

